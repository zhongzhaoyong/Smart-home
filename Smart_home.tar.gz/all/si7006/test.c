#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>

#define Temperature _IOWR('a',0,short)
#define Humidity _IOWR('a',1,short)
#define GET_CMD_SIZE(cmd) ((cmd>>16)&0x3fff)
int main(int argc, const char *argv[])
{
	int fd;
	char data[2] = {0};
	unsigned short val;

	float tem,hum;


	if((fd = open("/dev/mysi7006",O_RDWR)) < 0){
		perror("open error");
		exit(EXIT_FAILURE);
	}
	ioctl(fd,Temperature,data);
	printf("data[0] = %d,data[1] = %d\n",data[0],data[1]);
	val = data[1];
	val = val << 8 | data[0];
	tem = (175.72 * val) / 65536 - 46.85;
	hum = (125 * val) / 65536 - 6;
	printf("TEM = %f,HUM = %f\n",tem,hum);

	close(fd);
	return 0;
}


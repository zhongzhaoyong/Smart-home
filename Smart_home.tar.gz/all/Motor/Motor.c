#include <linux/init.h>
#include <linux/module.h>
#include <linux/mod_devicetable.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/slab.h>
#include <linux/io.h>
#include <linux/uaccess.h>
#include "stm32mp1xx_gpio.h"
#include "stm32mp1xx_rcc.h"
#include "stm32mp1xx_TIM.h"

#define MOTORNAME "myMotor"

struct cdev *cdev;
struct class *cls;
struct device *dev;
wait_queue_head_t wq_head;


int major = 0;
int minor = 0;
struct gpiof
{
	unsigned int *moder;
	unsigned int *odr;
	unsigned int *afrl;
	unsigned int *rcc;
};

struct tim
{
	unsigned int *cr1;
	unsigned int *ccmr1;
	unsigned int *ccer;
	unsigned int *psc;
	unsigned int *arr;
	unsigned int *ccr1;
	unsigned int *bdtr;
};

struct tim tim16;
struct gpiof gpiof6;

unsigned int *rcc_TIM16;
//unsigned int *rcc_TIMg2;

int myMotor_open(struct inode *inode,struct file *file)
{
	printk("%s:%d\n",__func__,__LINE__);
	return 0;
}

int myMotor_close(struct inode *inode,struct file *file)
{
	printk("%s:%d\n",__func__,__LINE__);
	return 0;
}

long myMotor_ioctl(struct file *file, unsigned int cmd,unsigned long args)
{
	switch(cmd)
	{
	case 0:
			*tim16.bdtr |= (0x1 << 15);
		break;
	case 1:
			*tim16.bdtr &= (~(0x1 << 15));
		break;
	}
	return 0;
}

const struct file_operations fops = {
	.open = myMotor_open,
	.unlocked_ioctl = myMotor_ioctl,
	.release = myMotor_close,
};

int __init myMotor_init(void)
{
	int ret;
	dev_t devno;
	printk("%s:%d\n",__func__,__LINE__);

	cdev = cdev_alloc();
	if(cdev == NULL)
	{
		printk("cdev alloc error\n");
		ret = -ENOMEM;
		return ret;
	}

	cdev_init(cdev,&fops);

	ret = alloc_chrdev_region(&devno,minor,1,"myMotor");
	if(ret)
	{
		printk("alloc device number error\n");
		goto ERR1;
	}
	major = MAJOR(devno);
	minor = MINOR(devno);

	ret = cdev_add(cdev,devno,1);
	if(ret)
	{
		printk("cdev register error\n");
		goto ERR2;
	}

	cls = class_create(THIS_MODULE,"2");
	if(IS_ERR(cls))
	{
		printk("class create error\n");
		ret = PTR_ERR(cls);
		goto ERR3;
	}
	dev = device_create(cls,NULL,devno,NULL,MOTORNAME);
	if(IS_ERR(dev))
	{
		printk("device create error\n");
		ret = PTR_ERR(dev);
		goto ERR4;
	}

	init_waitqueue_head(&wq_head);

	gpiof6.moder = ioremap((unsigned int)&GPIOF->MODER,4);
	if(gpiof6.moder == NULL)
	{
		printk("ioremap gpiof6.moder error\n");
		goto ERR5;
	}

	gpiof6.odr = ioremap((unsigned int)&GPIOF->ODR,4);
	if(gpiof6.odr == NULL)
	{
		printk("ioremap gpiof6.odr error\n");
		goto ERR5;
	}
	
	gpiof6.rcc = ioremap((unsigned int)&RCC->MP_AHB4ENSETR,4);
	if(gpiof6.rcc == NULL)
	{
		printk("ioremap gpiof6.rcc error\n");
		goto ERR5;
	}

	gpiof6.afrl = ioremap((unsigned int)&GPIOF->AFRL,4);
	if(gpiof6.afrl == NULL)
	{
		printk("ioremap gpiof6.afrl error\n");
		goto ERR5;
	}

	rcc_TIM16 = ioremap((unsigned int)&RCC->MP_APB2ENSETR,4);
	if(rcc_TIM16 == NULL)
	{
		printk("ioremap rcc_TIM16 error\n");
		goto ERR5;
	}
/*
	rcc_TIMg2 = ioremap((unsigned int)&RCC->TIMG2PRER,4);
	if(rcc_TIMg2 == NULL)
	{
		printk("ioremap rcc_TIMg2 error\n");
		goto ERR4;
	}
*/
	tim16.cr1 = ioremap((unsigned int)&TIM16->CR1,4);
	if(tim16.cr1 == NULL)
	{
		printk("ioremap tim16.cr1 error\n");
		goto ERR5;
	}
	
	tim16.ccmr1 = ioremap((unsigned int)&TIM16->CCMR1,4);
	if(tim16.ccmr1 == NULL)
	{
		printk("ioremap tim16.ccmr1 error\n");
		goto ERR5;
	}
	
	tim16.ccer = ioremap((unsigned int)&TIM16->CCER,4);
	if(tim16.ccer == NULL)
	{
		printk("ioremap tim16.ccer error\n");
		goto ERR5;
	}
	
	tim16.psc = ioremap((unsigned int)&TIM16->PSC,4);
	if(tim16.psc == NULL)
	{
		printk("ioremap tim16.psc error\n");
		goto ERR5;
	}
	
	tim16.arr = ioremap((unsigned int)&TIM16->ARR,4);
	if(tim16.arr == NULL)
	{
		printk("ioremap tim16.arr error\n");
		goto ERR5;
	}
	
	tim16.ccr1 = ioremap((unsigned int)&TIM16->CCR1,4);
	if(tim16.ccr1 == NULL)
	{
		printk("ioremap tim16.ccr1 error\n");
		goto ERR5;
	}
	
	tim16.bdtr = ioremap((unsigned int)&TIM16->BDTR,4);
	if(tim16.bdtr == NULL)
	{
		printk("ioremap tim16.bdtr error\n");
		goto ERR5;
	}

	*gpiof6.rcc |= (0x1 << 5);
	*rcc_TIM16 |= (0x1 << 3);
//	*rcc_TIMg2 |= (0x1);
	*gpiof6.moder &= (~(0x3 << 12));
	*gpiof6.moder |= (0x2 << 12);
	*gpiof6.afrl &= (~(0xf << 24));
	*gpiof6.afrl |= (0x1 << 24);

	*tim16.cr1 |= (0x1 << 7);
	*tim16.cr1 &= (~(0x3 << 5));
	*tim16.cr1 |= (0x1 << 4);
	*tim16.cr1 |= (0x1);

	*tim16.ccmr1 &= (~(0x1 << 16));
	*tim16.ccmr1 &= (~(0x7 << 4));
	*tim16.ccmr1 |= (0x6 << 4);


	*tim16.ccmr1 |= (0x1 << 3);
//	*tim16.ccmr1 &= (~(0x3));

	*tim16.ccer &= (~(0x1 << 3));
	*tim16.ccer |= (0x1 << 1);
	*tim16.ccer |= (0x1 << 2);
	*tim16.ccer |= (0x1);

	*tim16.psc &= (~(0xffff));
	*tim16.psc |= (208);

	*tim16.arr &= (~(0xffff));
	*tim16.arr |= (1000);

	*tim16.ccr1 &= (~(0xffff));
	*tim16.ccr1 |= (500);

	
	return 0;
ERR5:
	device_destroy(cls,devno);

ERR4:
	class_destroy(cls);

ERR3:
	cdev_del(cdev);

ERR2:
	unregister_chrdev_region(devno,1);

ERR1:
	kfree(cdev);
	return ret;
}

void __exit myMotor_exit(void)
{
	int devno;
	devno = ((major << 20) + minor);
	iounmap(gpiof6.moder);
	iounmap(gpiof6.odr);
	iounmap(gpiof6.rcc);
	iounmap(gpiof6.afrl);

	iounmap(rcc_TIM16);

	iounmap(tim16.cr1);
	iounmap(tim16.ccmr1);
	iounmap(tim16.ccer);
	iounmap(tim16.psc);
	iounmap(tim16.arr);
	iounmap(tim16.ccr1);
	iounmap(tim16.bdtr);
	
	device_destroy(cls,devno);

	class_destroy(cls);

	cdev_del(cdev);

	unregister_chrdev_region(devno,1);

	kfree(cdev);
}

module_init(myMotor_init);
module_exit(myMotor_exit);
MODULE_LICENSE("GPL");


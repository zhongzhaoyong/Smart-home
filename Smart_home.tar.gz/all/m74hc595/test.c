#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>

int main(int argc, const char *argv[])
{
	int which=0;
	int data=0;
	int fd;
	fd = open("/dev/m74hc595",O_RDWR);
	if(fd < 0){
		perror("open error");
		return -1;
	}

	while(1){
		ioctl(fd,0,1234);
	}

	close(fd);
	return 0;
}

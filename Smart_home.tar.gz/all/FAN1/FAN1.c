#include <linux/init.h>
#include <linux/module.h>
#include <linux/mod_devicetable.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/slab.h>
#include <linux/io.h>
#include <linux/uaccess.h>
#include "stm32mp1xx_gpio.h"
#include "stm32mp1xx_rcc.h"
#include "stm32mp1xx_TIM.h"

#define FANNAME "myFAN"

struct cdev *cdev;
struct class *cls;
struct device *dev;
wait_queue_head_t wq_head;


int major = 0;
int minor = 0;
struct gpioe
{
	unsigned int *moder;
	unsigned int *odr;
	unsigned int *afrh;
	unsigned int *rcc;
};

struct tim
{
	unsigned int *cr1;
	unsigned int *ccmr1;
	unsigned int *ccer;
	unsigned int *psc;
	unsigned int *arr;
	unsigned int *ccr1;
	unsigned int *bdtr;
};

struct tim tim1;
struct gpioe gpioe9;

unsigned int *rcc_TIM1;
//unsigned int *rcc_TIMg2;
TIM_t TIM_1;

int myFAN_open(struct inode *inode,struct file *file)
{
	printk("%s:%d\n",__func__,__LINE__);
	return 0;
}

int myFAN_close(struct inode *inode,struct file *file)
{
	printk("%s:%d\n",__func__,__LINE__);
	return 0;
}

long myFAN_ioctl(struct file *file, unsigned int cmd,unsigned long args)
{
	switch(cmd)
	{
case 0:
	*tim1.bdtr |= (0x1 << 15);
	break;
case 1:
	*tim1.bdtr &= (~(0x1 << 15));
	break;
	}
	return 0;
}

const struct file_operations fops = {
	.open = myFAN_open,
	.unlocked_ioctl = myFAN_ioctl,
	.release = myFAN_close,
};

int __init myFAN_init(void)
{
	int ret;
	dev_t devno;
	printk("%s:%d\n",__func__,__LINE__);

	cdev = cdev_alloc();
	if(cdev == NULL)
	{
		printk("cdev alloc error\n");
		ret = -ENOMEM;
		return ret;
	}

	cdev_init(cdev,&fops);

	ret = alloc_chrdev_region(&devno,minor,1,"FAN");
	if(ret)
	{
		printk("alloc device number error\n");
		goto ERR1;
	}
	major = MAJOR(devno);
	minor = MINOR(devno);

	ret = cdev_add(cdev,devno,1);
	if(ret)
	{
		printk("cdev register error\n");
		goto ERR2;
	}

	cls = class_create(THIS_MODULE,"1");
	if(IS_ERR(cls))
	{
		printk("class create error\n");
		ret = PTR_ERR(cls);
		goto ERR3;
	}
	dev = device_create(cls,NULL,devno,NULL,FANNAME);
	if(IS_ERR(dev))
	{
		printk("device create error\n");
		ret = PTR_ERR(dev);
		goto ERR4;
	}

	init_waitqueue_head(&wq_head);

	gpioe9.moder = ioremap((unsigned int)&GPIOE->MODER,4);
	if(gpioe9.moder == NULL)
	{
		printk("ioremap gpioe9.moder error\n");
		goto ERR5;
	}

	gpioe9.odr = ioremap((unsigned int)&GPIOE->ODR,4);
	if(gpioe9.odr == NULL)
	{
		printk("ioremap gpioe9.odr error\n");
		goto ERR5;
	}
	
	gpioe9.rcc = ioremap((unsigned int)&RCC->MP_AHB4ENSETR,4);
	if(gpioe9.rcc == NULL)
	{
		printk("ioremap gpioe9.rcc error\n");
		goto ERR5;
	}

	gpioe9.afrh = ioremap((unsigned int)&GPIOE->AFRH,4);
	if(gpioe9.afrh == NULL)
	{
		printk("ioremap gpioe9.afrh error\n");
		goto ERR5;
	}

	rcc_TIM1 = ioremap((unsigned int)&RCC->MP_APB2ENSETR,4);
	if(rcc_TIM1 == NULL)
	{
		printk("ioremap rcc_TIM1 error\n");
		goto ERR5;
	}
/*
	rcc_TIMg2 = ioremap((unsigned int)&RCC->TIMG2PRER,4);
	if(rcc_TIMg2 == NULL)
	{
		printk("ioremap rcc_TIMg2 error\n");
		goto ERR4;
	}
*/
	tim1.cr1 = ioremap((unsigned int)&TIM1->CR1,4);
	if(tim1.cr1 == NULL)
	{
		printk("ioremap tim.cr1 error\n");
		goto ERR5;
	}
	
	tim1.ccmr1 = ioremap((unsigned int)&TIM1->CCMR1,4);
	if(tim1.ccmr1 == NULL)
	{
		printk("ioremap tim.ccmr1 error\n");
		goto ERR5;
	}
	
	tim1.ccer = ioremap((unsigned int)&TIM1->CCER,4);
	if(tim1.ccer == NULL)
	{
		printk("ioremap tim.ccer error\n");
		goto ERR5;
	}
	
	tim1.psc = ioremap((unsigned int)&TIM1->PSC,4);
	if(tim1.psc == NULL)
	{
		printk("ioremap tim.psc error\n");
		goto ERR5;
	}
	
	tim1.arr = ioremap((unsigned int)&TIM1->ARR,4);
	if(tim1.arr == NULL)
	{
		printk("ioremap tim.arr error\n");
		goto ERR5;
	}
	
	tim1.ccr1 = ioremap((unsigned int)&TIM1->CCR1,4);
	if(tim1.ccr1 == NULL)
	{
		printk("ioremap tim.ccr1 error\n");
		goto ERR5;
	}
	
	tim1.bdtr = ioremap((unsigned int)&TIM1->BDTR,4);
	if(tim1.bdtr == NULL)
	{
		printk("ioremap tim.bdtr error\n");
		goto ERR5;
	}

	*gpioe9.rcc |= (0x1 << 4);
	*rcc_TIM1 |= (0x1);
//	*rcc_TIMg2 |= (0x1);
	*gpioe9.moder &= (~(0x3 << 18));
	*gpioe9.moder |= (0x2 << 18);
	*gpioe9.afrh &= (~(0xf << 4));
	*gpioe9.afrh |= (0x1 << 4);

	*tim1.cr1 |= (0x1 << 7);
	*tim1.cr1 &= (~(0x3 << 5));
	*tim1.cr1 |= (0x1 << 4);
	*tim1.cr1 |= (0x1);

	*tim1.ccmr1 &= (~(0x1 << 16));
	*tim1.ccmr1 &= (~(0x7 << 4));
	*tim1.ccmr1 |= (0x6 << 4);


	*tim1.ccmr1 |= (0x1 << 3);
//	*tim1.ccmr1 &= (~(0x3));

	*tim1.ccer &= (~(0x1 << 3));
	*tim1.ccer |= (0x1 << 1);
	*tim1.ccer |= (0x1 << 2);
	*tim1.ccer |= (0x1);

	*tim1.psc &= (~(0xffff));
	*tim1.psc |= (208);

	*tim1.arr &= (~(0xffff));
	*tim1.arr |= (1000);

	*tim1.ccr1 &= (~(0xffff));
	*tim1.ccr1 |= (500);

	
	return 0;
ERR5:
	device_destroy(cls,devno);

ERR4:
	class_destroy(cls);

ERR3:
	cdev_del(cdev);

ERR2:
	unregister_chrdev_region(devno,1);

ERR1:
	kfree(cdev);
	return ret;
}

void __exit myFAN_exit(void)
{
	int devno;
	devno = ((major << 20) + minor);
	iounmap(gpioe9.moder);
	iounmap(gpioe9.odr);
	iounmap(gpioe9.rcc);
	iounmap(gpioe9.afrh);

	iounmap(rcc_TIM1);

	iounmap(tim1.cr1);
	iounmap(tim1.ccmr1);
	iounmap(tim1.ccer);
	iounmap(tim1.psc);
	iounmap(tim1.arr);
	iounmap(tim1.ccr1);
	iounmap(tim1.bdtr);
	
	device_destroy(cls,devno);

	class_destroy(cls);

	cdev_del(cdev);

	unregister_chrdev_region(devno,1);

	kfree(cdev);
}

module_init(myFAN_init);
module_exit(myFAN_exit);
MODULE_LICENSE("GPL");

